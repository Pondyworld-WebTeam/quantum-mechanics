<div class="header-area wow fadeInDown header-absolate" id="nav" data-0="position:fixed;" data-top-top="position:fixed;top:0;" data-edge-strategy="set">
        <div class="container">
            <div class="row">
                <div class="col-4 d-block d-lg-none">
                    <div class="mobile-menu"></div>
                </div>
                <div class="col-4 col-lg-2">
                    <div class="logo-area">
                        <a href="index.php"><img src="assets/img/m_SC_Logo_Png.png" alt=""></a>
                    </div>
                </div>
                <div class="col-4 col-lg-8 d-none d-lg-block">
                    <div class="main-menu text-center">
                        <nav>
                            <ul id="slick-nav">
                                <li><a class="scroll" href="index.php#home">home</a>
                                   <!--  <ul>
                                        <li><a href="index.html">Version 1</a></li>
                                        <li><a href="index2.html">Version 2</a></li>
                                        <li><a href="blog.html">blog</a></li>
                                        <li><a href="single-blog.html">single blog</a></li>
                                    </ul> -->
                                </li>
                                <li><a class="scroll" href="index.php#chairperson">Chairperson</a>
                                </li>
                                <!-- <li><a class="scroll" href="index.php#session">Session</a></li> -->
                                <li><a class="scroll" href="index.php#importantdate">Important Dates</a></li>
                                <!-- <li><a class="scroll" href="index.php#moreinfo">More Info</a></li> -->
                                <!--<li><a class="scroll" href="#">Helpdisk</a></li>-->
                                <!-- <li><a class="scroll" href="#apps">APP</a></li>
                                <li><a class="scroll" href="#faq">FAQ</a></li> -->
                                <!-- <li><a class="scroll" href="#contact">Registration</a></li> -->
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-4 col-lg-2 text-right rr">
                    <a href="reg.php" class="logibtn gradient-btn">Registration</a>
                </div>
                
            </div>
        </div>
    </div>