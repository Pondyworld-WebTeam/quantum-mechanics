<?php

// test api key&secrete id
$keyId = 'rzp_test_5N12eQej2zW2C9';
$keySecret = '1yUiZklbDCqSsahcN7NaURaH';
$displayCurrency = 'INR';

// $keyId = 'rzp_test_kSKqOUko0u35Z4';
// $keySecret = 'PaC6Q2W112RKmUdZN1dbSsAF';
// $displayCurrency = 'INR';

// live api key&secrete id
// $keyId = 'rzp_live_Yk5GWbWYmp8r04';
// $keySecret = 'f2We5TsrQHuvgzWgD8zm6PRW';
// $displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
