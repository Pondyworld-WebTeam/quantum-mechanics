<?php
// $con=mysqli_connect("localhost","root","","webinar");
$con=mysqli_connect("localhost","colossal_colossalmeeting","colossal1234!","colossal_colossalmeeting");
?>